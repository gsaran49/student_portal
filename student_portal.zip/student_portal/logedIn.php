<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TailWebs.</title>
    <link rel="stylesheet" type="text/css" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<?php
session_start();

if (isset($_SESSION['logged_in'])) {
    header("Location: ../view/student_list.php");
    exit();
}
?>
<body>
    <div class="heading-container">
        <h2>tailWebs.</h2>
    </div>
    <form action="../controller/login.php" method="post">
        <?php if (isset($_GET['error'])) { ?>
            <p class="error"><?php echo htmlspecialchars($_GET['error']); ?></p>
        <?php } ?>
        <label>Username</label>
        <div class="input-container">
            <i class="fas fa-user input-icon"></i>
            <input type="text" name="uname" placeholder="User Name" required>
        </div>
        <label>Password</label>
        <div class="input-container">
            <i class="fas fa-lock input-icon"></i>
            <input type="password" name="password" id="password" placeholder="Password" required>
            <i class="fas fa-eye toggle-icon" id="togglePassword" style="cursor: pointer;"></i>
        </div>

        <a class='forget-password' href="forgot_password.php">Forgot Password?</a>
        <br>
        <button type="submit">Login</button>
        
    </form>

    <script>
        const togglePassword = document.querySelector('#togglePassword');
        const password = document.querySelector('#password');
        togglePassword.addEventListener('click', function () {
            const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
            password.setAttribute('type', type);
            this.classList.toggle('fa-eye-slash');
        });
    </script>
</body>
</html>
