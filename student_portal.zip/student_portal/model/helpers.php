<?php

function getAllStudents($pdo) {
    $stmt = $pdo->query("SELECT * FROM students");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function getStudentById($pdo, $id) {
    $stmt = $pdo->prepare("SELECT * FROM students WHERE id = ?");
    $stmt->execute([$id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function deleteStudent($pdo, $id) {
    $stmt = $pdo->prepare("DELETE FROM students WHERE id = ?");
    return $stmt->execute([$id]);
}

function addOrUpdateStudent($pdo, $id=0,$name, $subject, $mark) {
    $stmt = $pdo->prepare("SELECT id, mark FROM students WHERE name = ? AND subject = ?");
    $stmt->execute([$name, $subject]);
    $student = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($student) {
        $newMark = $student['mark'] + $mark;
        $updateStmt = $pdo->prepare("UPDATE students SET mark = ? WHERE id = ?");
        return $updateStmt->execute([$newMark, $student['id']]);
    } else {
        $insertStmt = $pdo->prepare("INSERT INTO students (name, subject, mark) VALUES (?, ?, ?)");
        return $insertStmt->execute([$name, $subject, $mark]);
    }
}
?>
