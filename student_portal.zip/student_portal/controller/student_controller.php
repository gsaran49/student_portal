<?php
require '../model/db.php';
require '../model/helpers.php';


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents("php://input"), true);

    function validateFields($data, $isUpdate = false) {
        $errors = [];

        if (empty($data['name']) || !is_string($data['name'])) {
            $errors['name'] = 'Name is required and should be a valid string';
        }

        if (empty($data['subject']) || !is_string($data['subject'])) {
            $errors['subject'] = 'Subject is required and should be a valid string';
        }

        if (!isset($data['mark']) || !is_numeric($data['mark']) || $data['mark'] < 0 || $data['mark'] > 100) {
            $errors['mark'] = 'Marks are required and should be a number between 0 and 100';
        }

        return $errors;
    }

    if (isset($data['action'])) {
        switch ($data['action']) {
            case 'updateStudent':
                $id = $data['id'];
                $name = $data['name'];
                $subject = $data['subject'];
                $mark = $data['mark'];
                $result = addOrUpdateStudent($pdo, $id, $name, $subject, $mark);
                echo json_encode(['success' => $result]);
                break;
            
            case 'deleteStudent':
                $id = $data['id'];
                $result = deleteStudent($pdo, $id);
                echo json_encode(['success' => $result]);
                break;

            case 'addStudent':
                $id = isset($data['id']) ? $data['id'] : '';
                $name = $data['name'];
                $subject = $data['subject'];
                $mark = $data['mark'];
                $result = addOrUpdateStudent($pdo,$id, $name, $subject, $mark);
                echo json_encode(['success' => $result]);
                break;
        }
    }
} else {
    $students = getAllStudents($pdo);
    include '../view/student_list.php';
}
?>
