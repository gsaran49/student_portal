<?php
session_start();

if (isset($_SESSION['user'])) {
    header("Location: ../view/student_list.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['uname'];
    $password = $_POST['password'];
    $conn = new mysqli('localhost', 'root', '', 'test');

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");

    if ($stmt === false) {
        die("Error preparing the statement: " . $conn->error);
    }

    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            $_SESSION['user'] = $user['username'];
            $_SESSION['logged_in'] = true;
            header("Location: ../view/student_list.php");   
            exit();
        } else {
            header("Location: ../logedIn.php?error=Invalid password");
            exit();
        }
    } else {
        header("Location: ../logedIn.php?error=User not found");
        exit();
    }
}
