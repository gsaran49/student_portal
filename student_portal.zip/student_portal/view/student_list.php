<?php
session_start();
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header("Location: ../view/logedIn.php");
    exit;
}
require '../model/db.php';
require '../model/helpers.php';

$students = getAllStudents($pdo);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Management</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" type="text/css" href="../css/studentList.css">
</head>
<body>
    <div class="header">
        <h1>tailWebs.</h1>
        <div class="nav">
            <a href="../view/student_list.php">Home</a>
            <a href="../../logout.php">Logout</a>
        </div>
    </div>
    <div class="main-content">
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Subject</th>
                        <th>Marks</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($students as $student): 
                        $initial = strtoupper($student['name'][0]);
                    ?>
                        <tr>
                            <td class="student-name" data-initial="<?php echo htmlspecialchars($initial); ?>">
                                <?php echo htmlspecialchars($student['name']); ?>
                            </td>
                            <td><?php echo htmlspecialchars($student['subject']); ?></td>
                            <td><?php echo $student['mark']; ?></td>
                            <td class="actions">
                                <div class="dropdown">
                                    <button>▼</button>
                                    <div class="dropdown-content">
                                       
                                        <button onclick="openEditModal(<?php echo $student['id']; ?>, '<?php echo htmlspecialchars($student['name']); ?>', '<?php echo htmlspecialchars($student['subject']); ?>', <?php echo $student['mark']; ?>)">Edit</button>
                                        <button onclick="deleteStudent(<?php echo $student['id']; ?>)">Delete</button>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <button class="add-btn" onclick="openAddModal()">Add Student</button>
        </div>
    </div>

    <div id="addModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeAddModal()">&times;</span>
            <form id="addForm">
                <div class="form-group">
                    <label for="addName">Name:</label>
                    <div class="input-icon-container">
                    <i class="fas fa-user input-icon"></i>
                    <input type="text" id="addName" class="form-input" required placeholder="Enter Name">
                </div>
                </div>
                <div class="form-group">
                    <label for="addSubject">Subject:</label>
                    <div class="input-icon-container">
                    <i class="fas fa-book input-icon"></i>
                    <input type="text" id="addSubject" class="form-input" required placeholder="Enter Subject">
                </div>
                </div>
                <div class="form-group">
                    <label for="addMark">Marks:</label>
                    <div class="input-icon-container">
                    <i class="fas fa-percentage input-icon"></i>
                    <input type="number" id="addMark" class="form-input" required placeholder="Enter Marks">
                </div>
                </div>
                <div class="form-actions">
                    <button type="button" class="save-btn" onclick="saveAdd()">Add</button>
                </div>
            </form>
        </div>
    </div>

   
    <div id="editModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeEditModal()">&times;</span>
            <form id="editForm">
                <input type="hidden" id="editStudentId">
                <div class="form-group">
                    <label for="editName">Name:</label>
                    <div class="input-icon-container">
                    <i class="fas fa-user input-icon"></i>
                    <input type="text" id="editName" class="form-input" required placeholder="Enter Name">
                </div>
                </div>
                <div class="form-group">
                    <label for="editSubject">Subject:</label>
                    <div class="input-icon-container">
                    <i class="fas fa-book input-icon"></i>
                    <input type="text" id="editSubject" class="form-input" required placeholder="Enter Subject">
                     </div>
                </div>
                <div class="form-group">
                    <label for="editMark">Marks:</label>
                    <div class="input-icon-container">
                    <i class="fas fa-percentage input-icon"></i>
                    <input type="number" id="editMark" class="form-input" required placeholder="Enter Marks">
                </div>
                </div>
                <div class="form-actions">
                    <button type="button" class="save-btn" onclick="saveEdit()">Save</button>
                </div>
            </form>
        </div>
    </div>


    <script>
        function openAddModal() {
            document.getElementById('addName').value = '';
            document.getElementById('addSubject').value = '';
            document.getElementById('addMark').value = '';
            document.getElementById('addModal').style.display = "block";
        }

        function closeAddModal() {
            document.getElementById('addModal').style.display = "none";
        }

        function saveAdd() {
            const name = document.getElementById('addName').value;
            const subject = document.getElementById('addSubject').value;
            const mark = document.getElementById('addMark').value;

            fetch('../controller/student_controller.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: 'addStudent', name, subject, mark })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Student added successfully.');
                    location.reload();
                } else {
                    alert('Failed to add student.');
                }
            })
            .catch(error => alert('Error adding student.'));
        }

        function openEditModal(id, name, subject, mark) {
            document.getElementById('editStudentId').value = id;
            document.getElementById('editName').value = name;
            document.getElementById('editSubject').value = subject;
            document.getElementById('editMark').value = mark;
            document.getElementById('editModal').style.display = "block";
        }

        function closeEditModal() {
            document.getElementById('editModal').style.display = "none";
        }

        function saveEdit() {
            const id = document.getElementById('editStudentId').value;
            const name = document.getElementById('editName').value;
            const subject = document.getElementById('editSubject').value;
            const mark = document.getElementById('editMark').value;

            fetch('../controller/student_controller.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: 'updateStudent', id, name, subject, mark })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Student updated successfully.');
                    location.reload();
                } else {
                    alert('Failed to update student.');
                }
            })
            .catch(error => alert('Error updating student.'));
        }

        function deleteStudent(id) {
            fetch('../controller/student_controller.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: 'deleteStudent', id })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Student deleted successfully.');
                    location.reload();
                } else {
                    alert('Failed to delete student.');
                }
            })
            .catch(error => alert('Error deleting student.'));
        }
    </script>
</body>
</html>
